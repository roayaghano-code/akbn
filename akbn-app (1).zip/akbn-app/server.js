"use strict";
/* ak bn — self-hosted server (no dependencies, Node 20+).
   Serves the app, keeps accounts/data on disk, relays AI requests to the Anthropic API. */
const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, "data"));
const API_KEY = process.env.ANTHROPIC_API_KEY || "";
const BASE = (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, "");
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";
const MODEL_QUICK = process.env.ANTHROPIC_MODEL_QUICK || "claude-haiku-5-5";
const AI_PER_MIN = Number(process.env.AI_RATE_PER_MIN) || 12;
const MAX_DOC_BYTES = 256 * 1024;
const PUBLIC = path.join(__dirname, "public");

/* ---------- storage: one JSON file, kept in memory, saved atomically ---------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, "db.json");
let db = { users: {}, sessions: {}, docs: {} };
try { const j = JSON.parse(fs.readFileSync(DB_FILE, "utf8")); db = Object.assign(db, j); } catch (e) { /* first run */ }
let saveTimer = null;
function saveSoon() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; saveNow(); }, 300);
}
function saveNow() {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}
process.on("SIGTERM", () => { try { saveNow(); } catch (e) {} process.exit(0); });
process.on("SIGINT", () => { try { saveNow(); } catch (e) {} process.exit(0); });

/* ---------- helpers ---------- */
const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const rid = (n) => crypto.randomBytes(n).toString("base64url");
function normPhone(s) {
  s = String(s == null ? "" : s)
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x6f0))
    .replace(/[\s\-().‎‏‪-‮]/g, "");
  if (s[0] === "+") s = s.slice(1); else if (s.slice(0, 2) === "00") s = s.slice(2);
  return /^[1-9][0-9]{7,14}$/.test(s) ? s : "";
}
function scrypt(pw, salt) {
  return new Promise((ok, no) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? no(e) : ok(k))));
}
function send(res, code, obj, headers) {
  const b = JSON.stringify(obj);
  res.writeHead(code, Object.assign({ "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }, headers || {}));
  res.end(b);
}
function readBody(req, limit) {
  return new Promise((ok, no) => {
    let n = 0, big = false; const chunks = [];
    req.on("data", (c) => { n += c.length; if (n > limit) big = true; else chunks.push(c); });   /* keep draining so the 413 can be delivered */
    req.on("end", () => {
      if (big) return no(Object.assign(new Error("too large"), { status: 413 }));
      try { ok(chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {}); } catch (e) { no(Object.assign(new Error("bad json"), { status: 400 })); }
    });
    req.on("error", no);
  });
}
const clientIp = (req) => String((process.env.TRUST_PROXY ? (req.headers["x-forwarded-for"] || "").split(",")[0].trim() : "") || req.socket.remoteAddress || "");

/* simple in-memory rate limiter: key -> timestamps */
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now(); const a = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (a.length >= max) { hits.set(key, a); return true; }
  a.push(now); hits.set(key, a); return false;
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) { const f = a.filter((t) => now - t < 3600e3); if (f.length) hits.set(k, f); else hits.delete(k); } }, 600e3).unref();

/* ---------- auth ---------- */
function authUser(req) {
  const h = req.headers.authorization || "";
  const tok = h.startsWith("Bearer ") ? h.slice(7) : "";
  if (!tok) return null;
  const s = db.sessions[sha(tok)];
  if (!s || !db.users[s.uid]) return null;
  return { uid: s.uid, user: db.users[s.uid], hash: sha(tok) };
}
function newSession(uid) {
  const tok = rid(32); db.sessions[sha(tok)] = { uid, at: Date.now() }; saveSoon(); return tok;
}
async function handleAuth(req, res, kind) {
  const ip = clientIp(req);
  if (limited("auth:" + ip, 30, 10 * 60e3)) return send(res, 429, { error: "rate_limited" });
  const b = await readBody(req, 4096);
  const phone = normPhone(b.phone), pw = String(b.password || "");
  if (!phone) return send(res, 400, { error: "bad_phone" });
  if (pw.length < 8 || pw.length > 200) return send(res, 400, { error: "bad_password" });
  const existing = Object.keys(db.users).find((u) => db.users[u].phone === phone);
  if (kind === "signup") {
    if (existing) return send(res, 409, { error: "phone_taken" });
    const salt = crypto.randomBytes(16), hash = await scrypt(pw, salt);
    const uid = "u_" + rid(16);
    db.users[uid] = { phone, salt: salt.toString("hex"), hash: hash.toString("hex"), createdAt: Date.now() };
    return send(res, 200, { token: newSession(uid), uid, phone });
  }
  if (limited("login:" + phone, 8, 10 * 60e3)) return send(res, 429, { error: "rate_limited" });
  const u = existing && db.users[existing];
  const salt = u ? Buffer.from(u.salt, "hex") : crypto.randomBytes(16);
  const hash = await scrypt(pw, salt);
  if (!u || !crypto.timingSafeEqual(hash, Buffer.from(u.hash, "hex"))) return send(res, 401, { error: "bad_credentials" });
  return send(res, 200, { token: newSession(existing), uid: existing, phone });
}

/* ---------- document database ---------- */
const SEG = /^[A-Za-z0-9_\-.~:@+]{1,200}$/;
function parsePath(p) {
  if (typeof p !== "string" || !p || p.length > 1000) return null;
  const segs = p.split("/");
  if (segs.length > 15 || segs.some((s) => !SEG.test(s) || s === "." || s === "..")) return null;
  return segs;
}
/* same rules as the hosted version: private user data; directory and dm readable by every signed-in user, writable only under your own id */
function allowed(segs, uid, write) {
  if (segs[0] === "data" && segs[1] === "users") return segs.length >= 3 && segs[2] === uid;
  if (segs[0] === "directory" || segs[0] === "dm") return write ? segs.length >= 2 && segs[1] === uid : true;
  return false;
}
const conns = new Set();
function broadcast(p) {
  const segs = p.split("/");
  const line = "data: " + JSON.stringify({ p }) + "\n\n";
  for (const c of conns) if (allowed(segs, c.uid, false)) { try { c.res.write(line); } catch (e) {} }
}
function docBytes(v) { return Buffer.byteLength(JSON.stringify(v)); }
function isObj(v) { return v && typeof v === "object" && !Array.isArray(v); }

async function handleDb(req, res, url, au) {
  const p = url.searchParams.get("path"), segs = parsePath(p);
  if (!segs) return send(res, 400, { error: "bad_path" });
  const isDoc = segs.length % 2 === 0, m = req.method;
  if (url.pathname === "/api/col") {
    if (isDoc || m !== "GET") return send(res, 400, { error: "bad_path" });
    if (!allowed(segs, au.uid, false)) return send(res, 403, { error: "denied" });
    const prefix = p + "/", out = [];
    for (const k in db.docs) if (k.startsWith(prefix) && k.indexOf("/", prefix.length) < 0) out.push({ id: k.slice(prefix.length), data: db.docs[k] });
    const ord = url.searchParams.get("order"), asc = url.searchParams.get("dir") === "asc";
    if (ord) out.sort((a, b) => { const x = Number((a.data || {})[ord]) || 0, y = Number((b.data || {})[ord]) || 0; return asc ? x - y : y - x; });
    const lim = Number(url.searchParams.get("limit")) || 0;
    return send(res, 200, { docs: lim ? out.slice(0, lim) : out });
  }
  if (!isDoc) return send(res, 400, { error: "bad_path" });
  const write = m !== "GET";
  if (!allowed(segs, au.uid, write)) return send(res, 403, { error: "denied" });
  if (m === "GET") { const d = db.docs[p]; return send(res, 200, d === undefined ? { exists: false } : { exists: true, data: d }); }
  if (m === "DELETE") { delete db.docs[p]; saveSoon(); broadcast(p); return send(res, 200, { ok: true }); }
  if (m === "PUT" || m === "PATCH") {
    const b = await readBody(req, MAX_DOC_BYTES + 4096);
    if (!isObj(b.data)) return send(res, 400, { error: "bad_data" });
    const next = m === "PUT" ? b.data : Object.assign({}, db.docs[p] || {}, b.data);
    if (docBytes(next) > MAX_DOC_BYTES) return send(res, 413, { error: "too_large" });
    db.docs[p] = next; saveSoon(); broadcast(p);
    return send(res, 200, { ok: true });
  }
  return send(res, 405, { error: "method" });
}

/* ---------- AI relay (streams text back as lines of JSON) ---------- */
const aiBusy = new Map();
async function handleAi(req, res, au) {
  if (!API_KEY) return send(res, 503, { error: "server_config", detail: "ANTHROPIC_API_KEY is not set" });
  if (limited("ai:" + au.uid, AI_PER_MIN, 60e3)) return send(res, 429, { error: "rate_limited" });
  if ((aiBusy.get(au.uid) || 0) >= 3) return send(res, 429, { error: "rate_limited" });
  const b = await readBody(req, 26 * 1024 * 1024);
  let msgs = Array.isArray(b.messages) ? b.messages : null;
  if (!msgs || !msgs.length || msgs.length > 80) return send(res, 400, { error: "bad_messages" });
  let chars = 0;
  msgs = msgs.map((m) => { const c = String((m && m.content) || ""); chars += c.length; return { role: m && m.role === "assistant" ? "assistant" : "user", content: c }; });
  if (chars > 250000) return send(res, 413, { error: "too_large" });
  const imgs = Array.isArray(b.images) ? b.images.slice(0, 4) : [];
  if (imgs.length) {
    const last = msgs[msgs.length - 1];
    const blocks = [];
    for (const im of imgs) {
      if (!im || !/^image\/(png|jpeg|gif|webp)$/.test(im.media_type) || typeof im.data !== "string" || im.data.length > 8 * 1024 * 1024) return send(res, 400, { error: "bad_image" });
      blocks.push({ type: "image", source: { type: "base64", media_type: im.media_type, data: im.data } });
    }
    blocks.push({ type: "text", text: last.content || " " });
    last.content = blocks;
  }
  const ctl = new AbortController();
  req.on("close", () => { if (!res.writableEnded) ctl.abort(); });
  aiBusy.set(au.uid, (aiBusy.get(au.uid) || 0) + 1);
  const done = () => aiBusy.set(au.uid, Math.max(0, (aiBusy.get(au.uid) || 1) - 1));
  try {
    const up = await fetch(BASE + "/v1/messages", {
      method: "POST", signal: ctl.signal,
      headers: { "content-type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: b.tier === "quick" ? MODEL_QUICK : MODEL, max_tokens: Math.min(Number(b.max_tokens) || 4096, 8192), stream: true, messages: msgs })
    });
    if (!up.ok) {
      const code = up.status === 429 || up.status === 529 || up.status === 503 ? 429 : up.status === 401 || up.status === 403 ? 503 : 502;
      console.error("upstream error", up.status, (await up.text().catch(() => "")).slice(0, 300));
      return send(res, code, { error: code === 429 ? "rate_limited" : code === 503 ? "server_config" : "upstream" });
    }
    res.writeHead(200, { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-store", "x-accel-buffering": "no" });
    const dec = new TextDecoder(); let buf = "";
    for await (const chunk of up.body) {
      buf += dec.decode(chunk, { stream: true });
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const ev = buf.slice(0, i); buf = buf.slice(i + 2);
        const line = ev.split("\n").find((l) => l.startsWith("data:"));
        if (!line) continue;
        let j; try { j = JSON.parse(line.slice(5)); } catch (e) { continue; }
        if (j.type === "content_block_delta" && j.delta && typeof j.delta.text === "string") res.write(JSON.stringify({ t: j.delta.text }) + "\n");
        else if (j.type === "error") { res.write(JSON.stringify({ error: "upstream" }) + "\n"); }
      }
    }
    res.end(JSON.stringify({ done: true }) + "\n");
  } catch (e) {
    if (!res.headersSent) send(res, 502, { error: "upstream" }); else { try { res.end(JSON.stringify({ error: "upstream" }) + "\n"); } catch (e2) {} }
  } finally { done(); }
}

/* ---------- static files ---------- */
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json", ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon" };
const CSP = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";
function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname); if (rel === "/") rel = "/index.html";
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { "content-type": "text/plain" }); return res.end("Not found"); }
    const ext = path.extname(file);
    res.writeHead(200, {
      "content-type": MIME[ext] || "application/octet-stream",
      "cache-control": ext === ".html" || file.endsWith("sw.js") ? "no-cache" : "public, max-age=3600",
      "x-content-type-options": "nosniff", "referrer-policy": "no-referrer", "content-security-policy": CSP
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://x");
    if (!url.pathname.startsWith("/api/")) return serveStatic(req, res, url);
    if (url.pathname === "/api/health") return send(res, 200, { ok: true, ai: !!API_KEY });
    if (req.method === "POST" && url.pathname === "/api/signup") return await handleAuth(req, res, "signup");
    if (req.method === "POST" && url.pathname === "/api/login") return await handleAuth(req, res, "login");
    const au = authUser(req);
    if (!au) return send(res, 401, { error: "unauthenticated" });
    if (url.pathname === "/api/me") return send(res, 200, { uid: au.uid, phone: au.user.phone, ai: !!API_KEY });
    if (url.pathname === "/api/logout" && req.method === "POST") { delete db.sessions[au.hash]; saveSoon(); return send(res, 200, { ok: true }); }
    if (url.pathname === "/api/events") {
      res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-store", "x-accel-buffering": "no" });
      res.write(": open\n\n");
      const c = { res, uid: au.uid }; conns.add(c);
      const hb = setInterval(() => { try { res.write(": hb\n\n"); } catch (e) {} }, 25000);
      req.on("close", () => { clearInterval(hb); conns.delete(c); });
      return;
    }
    if (url.pathname === "/api/ai" && req.method === "POST") return await handleAi(req, res, au);
    if (url.pathname === "/api/doc" || url.pathname === "/api/col") return await handleDb(req, res, url, au);
    return send(res, 404, { error: "not_found" });
  } catch (e) {
    if (!res.headersSent) send(res, e && e.status ? e.status : 500, { error: e && e.status === 413 ? "too_large" : "server" });
    else { try { res.end(); } catch (e2) {} }
    if (!e || !e.status) console.error(e);
  }
});
server.requestTimeout = 0; server.headersTimeout = 30000;
server.listen(PORT, () => console.log("ak bn listening on :" + PORT + (API_KEY ? "" : "  (WARNING: ANTHROPIC_API_KEY is not set, the AI will be unavailable)")));

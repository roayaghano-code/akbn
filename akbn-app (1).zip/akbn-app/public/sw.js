/* minimal service worker: makes the app installable; the app itself always loads fresh from the server */
self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", function () { /* network only */ });

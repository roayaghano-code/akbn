/* Connects the ak bn page to its own server: sign-in, database, live updates, AI, downloads.
   It provides the same window.claude.use("db" | "user" | "sample" | "downloads") the page expects. */
(function () {
  "use strict";
  var TOKEN_KEY = "akbn-token", UID_KEY = "akbn-uid", PH_KEY = "akbn-phone";
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  var session = null;                 // {token, uid, phone}
  var authWaiters = [];
  var T = {
    ar: { title: "ak bn", login: "تسجيل الدخول", signup: "حساب جديد", phone: "رقم الهاتف", ph_hint: "بالصيغة الدولية مثل 2348012345678+", pw: "كلمة المرور", pw2: "تأكيد كلمة المرور", go_login: "دخول", go_signup: "إنشاء الحساب",
      e_phone: "أدخل رقماً صحيحاً بالصيغة الدولية.", e_pw: "كلمة المرور 8 أحرف على الأقل.", e_match: "كلمتا المرور غير متطابقتين.", bad_credentials: "الرقم أو كلمة المرور غير صحيحة.", phone_taken: "هذا الرقم مسجّل من قبل. سجّل الدخول.", rate_limited: "محاولات كثيرة. انتظر قليلاً.", e_net: "تعذّر الاتصال بالخادم.", busy: "لحظة...", note: "الرقم غير موثّق برسالة نصية." },
    en: { title: "ak bn", login: "Sign in", signup: "New account", phone: "Phone number", ph_hint: "International format, e.g. +2348012345678", pw: "Password", pw2: "Confirm password", go_login: "Sign in", go_signup: "Create account",
      e_phone: "Enter a valid number in international format.", e_pw: "Password must be at least 8 characters.", e_match: "Passwords don't match.", bad_credentials: "Wrong number or password.", phone_taken: "This number is already registered. Sign in.", rate_limited: "Too many attempts. Wait a moment.", e_net: "Couldn't reach the server.", busy: "One moment...", note: "The number isn't verified by SMS." },
    fr: { title: "ak bn", login: "Connexion", signup: "Nouveau compte", phone: "Numéro de téléphone", ph_hint: "Format international, ex. +2348012345678", pw: "Mot de passe", pw2: "Confirmer le mot de passe", go_login: "Se connecter", go_signup: "Créer le compte",
      e_phone: "Saisissez un numéro valide au format international.", e_pw: "Le mot de passe doit contenir au moins 8 caractères.", e_match: "Les mots de passe ne correspondent pas.", bad_credentials: "Numéro ou mot de passe incorrect.", phone_taken: "Ce numéro est déjà inscrit. Connectez-vous.", rate_limited: "Trop de tentatives. Patientez un peu.", e_net: "Impossible de joindre le serveur.", busy: "Un instant...", note: "Le numéro n'est pas vérifié par SMS." }
  };
  function lang() { var l = ls(["akbn-lang"][0]); if (l && T[l]) return l; var n = (navigator.language || "ar").slice(0, 2); return T[n] ? n : "ar"; }

  function api(method, url, body, opt) {
    var h = { "content-type": "application/json" };
    if (session) h.authorization = "Bearer " + session.token;
    return fetch(url, Object.assign({ method: method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) }, opt || {})).then(function (r) {
      if (r.status === 401 && session) { signOutLocal(); }
      if (r.ok) return r.json().catch(function () { return {}; });
      return r.json().catch(function () { return {}; }).then(function (j) {
        var e = new Error(j.error || ("http " + r.status));
        e.status = r.status; e.code = r.status === 429 ? "rate_limited" : (r.status === 413 || r.status === 400) ? "invalid_argument" : r.status === 403 ? "permission-denied" : j.error;
        throw e;
      });
    });
  }
  function signOutLocal() { session = null; ls(TOKEN_KEY, null); ls(UID_KEY, null); window.__akbnCred = null; location.reload(); }
  window.akbnLogout = function () { var p = session ? api("POST", "/api/logout") : Promise.resolve(); p.catch(function () {}).then(signOutLocal); };

  /* ---------- sign-in screen ---------- */
  function showGate() {
    return new Promise(function (resolve) {
      var L = lang(), t = T[L], mode = "login";
      var root = document.createElement("div");
      root.setAttribute("dir", L === "ar" ? "rtl" : "ltr");
      root.style.cssText = "position:fixed;inset:0;z-index:9999;display:grid;place-items:center;padding:16px;background:#F4F5FA;color:#14172B;font-family:'IBM Plex Sans Arabic',system-ui,-apple-system,'Segoe UI',sans-serif";
      var dark = window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches;
      if (dark) root.style.cssText += ";background:#0C0F1E;color:#E8EBFA";
      var card = document.createElement("form"); card.noValidate = true; card.id = "gate";
      card.style.cssText = "width:min(400px,100%);display:flex;flex-direction:column;gap:12px;text-align:center";
      var logo = document.createElementNS("http://www.w3.org/2000/svg", "svg"); logo.setAttribute("width", "72"); logo.setAttribute("height", "72"); logo.style.alignSelf = "center";
      var use = document.createElementNS("http://www.w3.org/2000/svg", "use"); use.setAttribute("href", "#logo"); logo.appendChild(use);
      var h1 = document.createElement("h1"); h1.textContent = t.title; h1.style.cssText = "margin:0;font-size:28px";
      var tabs = document.createElement("div"); tabs.style.cssText = "display:flex;gap:4px;background:" + (dark ? "#1B2147" : "#E6E9F5") + ";border-radius:12px;padding:4px";
      var tl = document.createElement("button"), ts = document.createElement("button"); tl.id = "gateLogin"; ts.id = "gateSignup";
      [tl, ts].forEach(function (b) { b.type = "button"; b.style.cssText = "flex:1;border:0;border-radius:9px;padding:8px;font:inherit;cursor:pointer;background:transparent;color:inherit"; tabs.appendChild(b); });
      function field(ph, type, auto) { var i = document.createElement("input"); i.type = type; i.placeholder = ph; i.setAttribute("aria-label", ph); i.autocomplete = auto; i.style.cssText = "font:inherit;padding:11px 14px;border-radius:12px;border:1px solid " + (dark ? "#262C52" : "#D8DCEB") + ";background:" + (dark ? "#141935" : "#fff") + ";color:inherit;width:100%"; return i; }
      var ph = field(t.phone, "tel", "tel"); ph.setAttribute("dir", "ltr"); ph.inputMode = "tel";
      var hint = document.createElement("small"); hint.textContent = t.ph_hint; hint.style.cssText = "opacity:.7;text-align:start";
      var pw = field(t.pw, "password", "current-password"), pw2 = field(t.pw2, "password", "new-password");
      var err = document.createElement("div"); err.setAttribute("role", "alert"); err.style.cssText = "color:" + (dark ? "#FF9B93" : "#B3261E") + ";min-height:1.3em;font-size:14px";
      var go = document.createElement("button"); go.type = "submit"; go.style.cssText = "border:0;border-radius:12px;padding:12px;font:inherit;font-weight:600;cursor:pointer;background:" + (dark ? "#8FA0FF" : "#3445B8") + ";color:" + (dark ? "#0C0F1E" : "#fff");
      var note = document.createElement("small"); note.textContent = t.note; note.style.opacity = ".6";
      function paint() {
        var on = "background:" + (dark ? "#141935" : "#fff") + ";font-weight:600";
        tl.textContent = t.login; ts.textContent = t.signup;
        tl.style.cssText += ";" + (mode === "login" ? on : "background:transparent;font-weight:400"); ts.style.cssText += ";" + (mode === "signup" ? on : "background:transparent;font-weight:400");
        pw2.style.display = mode === "signup" ? "" : "none"; pw.autocomplete = mode === "signup" ? "new-password" : "current-password";
        go.textContent = mode === "signup" ? t.go_signup : t.go_login; err.textContent = "";
      }
      tl.onclick = function () { mode = "login"; paint(); }; ts.onclick = function () { mode = "signup"; paint(); };
      card.onsubmit = function (e) {
        e.preventDefault(); err.textContent = "";
        var digits = normPhone(ph.value);
        if (!digits) { err.textContent = t.e_phone; return; }
        if (pw.value.length < 8) { err.textContent = t.e_pw; return; }
        if (mode === "signup" && pw.value !== pw2.value) { err.textContent = t.e_match; return; }
        go.disabled = true; err.textContent = t.busy;
        api("POST", mode === "signup" ? "/api/signup" : "/api/login", { phone: digits, password: pw.value }).then(function (r) {
          session = { token: r.token, uid: r.uid, phone: r.phone };
          ls(TOKEN_KEY, r.token); ls(UID_KEY, r.uid); ls(PH_KEY, r.phone);
          window.__akbnCred = { phone: r.phone, pw: pw.value };
          root.remove(); resolve();
        }).catch(function (e2) { go.disabled = false; err.textContent = t[e2.code] || t[e2.message] || t.e_net; });
      };
      [logo, h1, tabs, ph, hint, pw, pw2, err, go, note].forEach(function (n) { card.appendChild(n); });
      root.appendChild(card); document.body.appendChild(root); paint();
      setTimeout(function () { ph.focus(); }, 50);
    });
  }
  function normPhone(s) {
    s = String(s || "").replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 0x660); }).replace(/[۰-۹]/g, function (d) { return String(d.charCodeAt(0) - 0x6f0); }).replace(/[\s\-().‎‏‪-‮]/g, "");
    if (s.charAt(0) === "+") s = s.slice(1); else if (s.slice(0, 2) === "00") s = s.slice(2);
    return /^[1-9][0-9]{7,14}$/.test(s) ? s : "";
  }
  var authP = null;
  function ensureAuth() {
    if (authP) return authP;
    authP = new Promise(function (resolve) {
      function gate() { var go = function () { showGate().then(resolve); }; if (document.body) go(); else document.addEventListener("DOMContentLoaded", go); }
      var tok = ls(TOKEN_KEY);
      if (!tok) return gate();
      session = { token: tok, uid: ls(UID_KEY), phone: ls(PH_KEY) };
      api("GET", "/api/me").then(function (r) { session.uid = r.uid; session.phone = r.phone; resolve(); }).catch(function (e) {
        if (e && e.status === 401) { session = null; ls(TOKEN_KEY, null); gate(); } else resolve();   // offline: keep the session, calls will fail visibly
      });
    });
    return authP;
  }

  /* ---------- live updates ---------- */
  var listeners = [], evStarted = false;
  function startEvents() {
    if (evStarted) return; evStarted = true;
    var wait = 1000;
    (function loop() {
      var opened = false;
      fetch("/api/events", { headers: { authorization: "Bearer " + session.token } }).then(function (r) {
        if (!r.ok) throw new Error("ev");
        opened = true; wait = 1000; refreshAll();
        var rd = r.body.getReader(), dec = new TextDecoder(), buf = "";
        return (function pump() {
          return rd.read().then(function (x) {
            if (x.done) return;
            buf += dec.decode(x.value, { stream: true });
            var i;
            while ((i = buf.indexOf("\n\n")) >= 0) {
              var ev = buf.slice(0, i); buf = buf.slice(i + 2);
              var m = /^data: (.*)$/m.exec(ev);
              if (m) { try { dispatch(JSON.parse(m[1]).p); } catch (e) {} }
            }
            return pump();
          });
        })();
      }).catch(function () {}).then(function () { setTimeout(loop, wait); wait = Math.min(wait * 2, 15000); });
    })();
    document.addEventListener("visibilitychange", function () { if (!document.hidden) refreshAll(); });
  }
  function parentOf(p) { var i = p.lastIndexOf("/"); return i < 0 ? "" : p.slice(0, i); }
  function dispatch(p) { listeners.forEach(function (l) { if (l.isDoc ? l.path === p : l.path === parentOf(p)) l.refresh(); }); }
  function refreshAll() { listeners.forEach(function (l) { l.refresh(); }); }

  /* ---------- database ---------- */
  function newId() { var a = new Uint8Array(15); crypto.getRandomValues(a); return Array.prototype.map.call(a, function (b) { return b.toString(36).padStart(2, "0"); }).join("").slice(0, 20); }
  function docSnap(path, r) { return { exists: !!r.exists, id: path.split("/").pop(), data: function () { return r.exists ? JSON.parse(JSON.stringify(r.data)) : undefined; } }; }
  function enc(p) { return encodeURIComponent(p); }
  function docRef(path) {
    return {
      id: path.split("/").pop(), path: path,
      get: function () { return api("GET", "/api/doc?path=" + enc(path)).then(function (r) { return docSnap(path, r); }); },
      set: function (v) { return api("PUT", "/api/doc?path=" + enc(path), { data: v }).then(function () {}); },
      update: function (v) { return api("PATCH", "/api/doc?path=" + enc(path), { data: v }).then(function () {}); },
      delete: function () { return api("DELETE", "/api/doc?path=" + enc(path)).then(function () {}); },
      collection: function (n) { return colRef(path + "/" + n); },
      onSnapshot: function (cb, er) { return listen({ isDoc: true, path: path, fetch: function () { return api("GET", "/api/doc?path=" + enc(path)).then(function (r) { return { key: JSON.stringify(r), snap: docSnap(path, r) }; }); }, cb: cb, er: er }); }
    };
  }
  function colRef(path) {
    var ord = null, dir = "desc", lim = 0;
    function url() { return "/api/col?path=" + enc(path) + (ord ? "&order=" + enc(ord) + "&dir=" + dir : "") + (lim ? "&limit=" + lim : ""); }
    function wrap(r) { return { docs: r.docs.map(function (d) { return { id: d.id, data: function () { return JSON.parse(JSON.stringify(d.data)); } }; }) }; }
    var ref = {
      doc: function (id) { return docRef(path + "/" + (id || newId())); },
      get: function () { return api("GET", url()).then(wrap); },
      orderBy: function (f, d) { ord = f; dir = d === "asc" ? "asc" : "desc"; return ref; },
      limit: function (n) { lim = n; return ref; },
      onSnapshot: function (cb, er) { return listen({ isDoc: false, path: path, fetch: function () { return api("GET", url()).then(function (r) { return { key: JSON.stringify(r), snap: wrap(r) }; }); }, cb: cb, er: er }); }
    };
    return ref;
  }
  function listen(l) {
    var seq = 0, last = null, off = false, timer = 0;
    l.refresh = function () {
      if (off || timer) return;
      timer = setTimeout(function () {
        timer = 0; var my = ++seq;
        l.fetch().then(function (r) { if (off || my !== seq) return; if (r.key !== last) { last = r.key; l.cb(r.snap); } })
          .catch(function (e) { if (!off && l.er && last === null) { last = "err"; l.er(e); } });
      }, 20);
    };
    listeners.push(l); l.refresh(); startEvents();
    return function () { off = true; var i = listeners.indexOf(l); if (i >= 0) listeners.splice(i, 1); };
  }

  /* ---------- AI ---------- */
  function blobToB64(b) { return new Promise(function (ok, no) { var r = new FileReader(); r.onload = function () { ok(String(r.result).split(",")[1] || ""); }; r.onerror = no; r.readAsDataURL(b); }); }
  async function sample(messages, opts) {
    opts = opts || {};
    var msgs = typeof messages === "string" ? [{ role: "user", content: messages }] : messages;
    var body = { messages: msgs, tier: opts.modelTier === "quick" ? "quick" : "main" };
    if (opts.images && opts.images.length) {
      body.images = [];
      for (var i = 0; i < opts.images.length; i++) body.images.push({ media_type: opts.images[i].type || "image/jpeg", data: await blobToB64(opts.images[i]) });
    }
    var r = await fetch("/api/ai", { method: "POST", signal: opts.signal, headers: { "content-type": "application/json", authorization: "Bearer " + session.token }, body: JSON.stringify(body) });
    if (!r.ok) {
      var j = await r.json().catch(function () { return {}; });
      var e = new Error(j.error || "ai"); e.code = r.status === 429 ? "rate_limited" : (j.error === "server_config" || r.status === 401) ? "not_granted" : "error"; throw e;
    }
    var rd = r.body.getReader(), dec = new TextDecoder(), buf = "", text = "";
    for (;;) {
      var x = await rd.read(); if (x.done) break;
      buf += dec.decode(x.value, { stream: true });
      var k;
      while ((k = buf.indexOf("\n")) >= 0) {
        var line = buf.slice(0, k); buf = buf.slice(k + 1); if (!line) continue;
        var m; try { m = JSON.parse(line); } catch (e1) { continue; }
        if (m.t) { text += m.t; if (opts.onText) opts.onText({ text: text }); }
        else if (m.error) { var e2 = new Error(m.error); e2.code = "error"; throw e2; }
      }
    }
    return { text: text };
  }
  sample.json = async function (prompt, opts) {
    var p = (typeof prompt === "string" ? prompt : JSON.stringify(prompt)) + "\n\nReply with one valid JSON value only, no code fences and no other text.";
    var r = await sample(p, opts);
    var s = r.text.trim().replace(/^```(?:json)?\s*|\s*```$/g, "");
    var a = s.indexOf("{"), b = s.lastIndexOf("}");
    if (a >= 0 && b > a) s = s.slice(a, b + 1);
    return JSON.parse(s);
  };
  sample.limits = function () { return Promise.resolve({ images: true }); };

  var downloads = { save: function (o) {
    var blob = o.data instanceof Blob ? o.data : new Blob([String(o.data)], { type: "text/plain" });
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = o.filename || "download"; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 2000); return Promise.resolve();
  } };

  window.claude = { use: function (name) {
    if (name === "downloads") return Promise.resolve(downloads);
    if (name === "sample") return ensureAuth().then(function () { return sample; });
    if (name === "db") return ensureAuth().then(function () { return { doc: docRef, collection: colRef }; });
    if (name === "user") return ensureAuth().then(function () { return { me: function () { return Promise.resolve({ id: session.uid, name: "", avatarUrl: null, phone: session.phone }); } }; });
    return Promise.reject(new Error("unsupported"));
  } };
})();
